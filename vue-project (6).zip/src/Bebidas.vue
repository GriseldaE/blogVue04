<script>
import { ref } from 'vue';

export default {
    name: 'App',
    
    setup() {
    
      

      const bebidas = ref([
              { nombre: 'Limonada de fresa', imagen: 'https://www.7diasdesabor.com/wp-content/uploads/2022/05/limonada-de-fresas-congeladas.jpg', precio:'$40'},
              { nombre: 'Soda', imagen: 'https://static.wixstatic.com/media/642b1e_d35b8d8c35af4c73a2f3a0320e836f9b~mv2.jpg/v1/fit/w_500,h_500,q_90/file.jpg', precio:'$45'},
        ]);
     
      
        
     return {
            bebidas };
    }
}
</script>

<template>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
        
        <body>
           <h1>Bebidas</h1>
           <nav id="Descripcion" v-for="item in bebidas">
    <h2 >{{ item.nombre }}</h2>
    <img :src="item.imagen"  class="img-fluid">
    <h3>{{item.precio}}</h3>
    
    </nav>
                 </body>
  
 
</template>