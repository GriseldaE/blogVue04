<script setup>
import { ref, computed } from 'vue'
import Inicio from './Inicio.vue'
import Entrada from './Entrada.vue'
import Comida from './Comida.vue'
import Postre from './Postre.vue'
import Bebida from './Bebidas.vue'

const routes = {
  '/': Inicio,
  '/Entrada': Entrada,
  '/Comida': Comida,
  '/Postre':Postre,
  '/Bebidas':Bebida
}

const currentPath = ref(window.location.hash)

window.addEventListener('hashchange', () => {
  currentPath.value = window.location.hash
})

const currentView = computed(() => {
  return routes[currentPath.value.slice(1) || '/'] || NotFound
})

</script>

<template>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<nav class="navbar navbar-expand-lg bg-body-tertiary">
<nav class="navbar bg-primary"  data-bs-theme="dark">
<div class="container-fluid"><div class="navbar-nav"><ul>
        <li><a class="nav-link" href="#/">Inicio</a> </li>
        <li> <a class="nav-link" href="#/Entrada">Entrada</a></li>
        <li> <a class="nav-link" href="#/Comida">Comida</a></li>
        <li><a class="nav-link" href="#/Postre">Postre</a></li>
        <li><a class="nav-link" href="#/Bebidas">Bebidas</a></li>
      
  </ul></div></div>

  <!-- Navbar content -->
  
</nav>

 |
 
 
  <component :is="currentView" />
 
  
 
</template>

