<script>
import { ref } from 'vue';

export default {
    name: 'App',
    
    setup() {
    
      

      const comidas = ref([
              { nombre: 'Tacos', imagen: 'https://upload.wikimedia.org/wikipedia/commons/7/73/001_Tacos_de_carnitas%2C_carne_asada_y_al_pastor.jpg', precio:'$150'},
              { nombre: 'Hamburguesa', imagen: 'https://www.recetasnestle.com.ec/sites/default/files/srh_recipes/4e4293857c03d819e4ae51de1e86d66a.jpg', precio:'$130'},
              { nombre: 'Pizza', imagen: 'https://images.ctfassets.net/n7hs0hadu6ro/1O0Be1dObiQBm17GQJHLj8/3fde720730f0b3616ecf5a82b928e7f9/pizza-a-domicilio-cerca-de-mi.jpg?w=1920&h=1281&fl=progressive&q=50&fm=jpg', precio:'$100'},
        ]);
     
      
        
     return {
            comidas };
    }
}
</script>

<template>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
        
        <body>
           <h1>Comida</h1>
           <nav id="Descripcion" v-for="item in comidas">
    <h2 >{{ item.nombre }}</h2>
    <img :src="item.imagen"  class="rounded float-start">
    <h3>{{item.precio}}</h3>
    
    </nav>
                 </body>

 
</template>