<script>
import { ref } from 'vue';

export default {
    name: 'App',
    
    setup() {
    
      

      const inicio = "En un vasto planeta con cerca de 8 000 millones de personas donde solo se escucha hablar de nuestras diferencias, hay algunas cosas importantes que nos conectan, y una de ellas es la comida. Nos vincula a todos. Todos la necesitamos, dependemos de ella, sobrevivimos gracias a ella y nos aporta felicidad."
        
      
      
        
     return {
            inicio};
    }
}
</script>

<template>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
        
        <body>
           <h1>Inicio</h1>
           <h3>{{inicio}}</h3>
      </body>
  
 
</template>