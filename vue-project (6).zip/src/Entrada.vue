<script>
import { ref } from 'vue';

export default {
    name: 'App',
    
    setup() {
    
      

      const entradas = ref([
            { nombre: 'Ceviche', imagen: 'http://malevamag.com/wp-content/uploads/2017/11/Ceviche-cremosos-Puerta-del-Inca-1200x800.jpg', precio:'$295'},
            { nombre: 'Papas con queso', imagen: 'https://marcellos.com.ec/wp-content/uploads/2023/02/webcheddarpapasRECETA-MARCE22-870x635.jpg', precio:'$121'},
            { nombre: 'Pan de ajo con queso', imagen: 'https://storage.googleapis.com/avena-recipes/2019/10/1571781316686.jpeg', precio:'$60'},
        ]);
      
      
        
     return {
            entradas };
    }
}
</script>

<template>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
        
        <body>
           <h1>Entrada</h1>
                 </body>

    <nav id="Descripcion" v-for="item in entradas">
    <h2 >{{ item.nombre }}</h2>
    <img :src="item.imagen"  class="img-fluid">
    <h3>{{item.precio}}</h3>
    
    </nav>
  
 
</template>