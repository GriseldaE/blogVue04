<script>
import { ref } from 'vue';

export default {
    name: 'App',
    
    setup() {
    
      

      const postres = ref([
              { nombre: 'Pastel de chocolate', imagen: 'https://www.eltiempo.com/files/article_main_1200/uploads/2023/03/14/6410f5956dc5d.jpeg', precio:'$75'},
              { nombre: 'Pay de queso', imagen: 'https://static.onecms.io/wp-content/uploads/sites/21/2017/03/29/pay-de-queso-al-horno.jpg-2000.jpg', precio:'$70'},
              
        ]);
     
      
        
     return {
            postres };
    }
}
</script>

<template>

 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        
        <body>
           <h1>Postre</h1>
           <nav id="Descripcion" v-for="item in postres">
    <h2 >{{ item.nombre }}</h2>
    <img :src="item.imagen" class="img-fluid">
    <h3>{{item.precio}}</h3>
    
    </nav>
                 </body>
  
 
</template>